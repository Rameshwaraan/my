const express=require('express');
const path=require('path');
const ejs=require('ejs');
const app=express();

app.use(express.static('public')); 
app.set('view engine','ejs');

//Create Server
app.listen(3000,()=>{
    console.log("App is Listening at port number 3000")
})

// Creating Routes  
app.get('/',(req,res)=>{
    res.render('dashboard'); 
})

app.get('/dashboard',(req,res)=>{
    res.render('dashboard'); 
})

app.get('/login',(req,res)=>{
    res.render('login'); 
})

app.get('/gLicense',(req,res)=>{
    res.render('gLicense'); 
})

app.get('/g2License',(req,res)=>{
    res.render('g2License'); 
})

